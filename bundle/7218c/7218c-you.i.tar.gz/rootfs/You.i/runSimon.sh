#!/bin/sh

mv /home/root/Spark /home/root/Spark.orig
killall Spark

killall ntpd
ntpd -n -d -q -g time.nrc.ca


export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:~/You.i/libs/
export XDG_RUNTIME_DIR=/run
export WAYLAND_DISPLAY=wayland-0

cd ~/You.i/
./Auryn

#mv /home/root/Spark.orig /home/root/Spark
